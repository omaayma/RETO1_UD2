package gestionAlumnos.Model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ModeloAlumnosJDBC implements IModeloAlumnos {

    private static String cadenaConexion = "jdbc:mysql://localhost:3306/instituto";
    private static String user = "root";
    private static String pass = "mysqlomayma";


    public ModeloAlumnosJDBC() {}

    // Método auxiliar para obtener la conexión
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(cadenaConexion, user, pass);
    }


    @Override
    public List<String> getAll() {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT DNI, nombre, apellidos, CP FROM alumnos";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String alumno = rs.getString("DNI") + "  "
                        + rs.getString("nombre") + "  "
                        + rs.getString("apellidos") + "  "
                        + rs.getString("CP");
                lista.add(alumno);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public Alumno getAlumnoPorDNI(String DNI) {
        Alumno alumno = null;
        String sql = "SELECT * FROM alumnos WHERE DNI = ?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, DNI);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    alumno = new Alumno();
                    alumno.setDNI(rs.getString("DNI"));
                    alumno.setNombre(rs.getString("nombre"));
                    alumno.setApellidos(rs.getString("apellidos"));
                    alumno.setCP(rs.getString("CP"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alumno;
    }

    @Override
    public boolean crear(Alumno alumno) {
        String sql = "INSERT INTO alumnos (DNI, nombre, apellidos, CP) VALUES (?, ?, ?, ?)";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, alumno.getDNI());
            ps.setString(2, alumno.getNombre());
            ps.setString(3, alumno.getApellidos());
            ps.setString(4, alumno.getCP());

            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean modificarAlumno(Alumno alumno) {

        String sql = "SELECT * FROM alumnos WHERE DNI = ?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(
                     sql,
                     ResultSet.TYPE_FORWARD_ONLY,
                     ResultSet.CONCUR_UPDATABLE)) {

            ps.setString(1, alumno.getDNI());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    rs.updateString("nombre", alumno.getNombre());
                    rs.updateString("apellidos", alumno.getApellidos());
                    rs.updateString("CP", alumno.getCP());
                    rs.updateRow();
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean eliminarAlumno(String DNI) {
        String sql = "DELETE FROM alumnos WHERE DNI = ?";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, DNI);
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

