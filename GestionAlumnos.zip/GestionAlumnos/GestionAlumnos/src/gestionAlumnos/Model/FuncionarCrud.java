package gestionAlumnos.Model;

public class FuncionarCrud {
	 public static void main(String[] args) {
	        ModeloAlumnosJDBC modelo = new ModeloAlumnosJDBC();

	        // Crear alumno
	        Alumno a1 = new Alumno();
	        a1.setDNI("12345678A");
	        a1.setNombre("Laura");
	        a1.setApellidos("Pérez Gómez");
	        a1.setCP("28080");
	        modelo.crear(a1);

	        // Mostrar todos
	        modelo.getAll().forEach(System.out::println);

	        // Buscar por DNI
	        System.out.println(modelo.getAlumnoPorDNI("12345678A"));

	        // Modificar
	        a1.setNombre("Laura Modificada");
	        modelo.modificarAlumno(a1);

	        // Eliminar
	        modelo.eliminarAlumno("12345678A");
	    }

}
