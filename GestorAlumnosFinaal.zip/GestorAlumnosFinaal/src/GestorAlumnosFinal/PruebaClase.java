package GestorAlumnosFinal;

import java.util.List;
import java.util.Scanner;

public class PruebaClase {

    public static void main(String[] args) {
    	
        AlumnoDAW daw = new AlumnoDAW();
        Scanner sc = new Scanner(System.in);

        try {
            // Mostrar alumnos existentes
            System.out.println("Alumnos en la base de datos:");
            List<Alumno> alumnos = daw.listar();
            for (Alumno a : alumnos) {
                System.out.println(a);
            }

            // Insertar un nuevo alumno
            System.out.println("\nInsertar nuevo alumno");
            System.out.print("DNI: ");
            String dni = sc.nextLine();
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();
            System.out.print("Nota: ");
            float nota = Float.parseFloat(sc.nextLine());
            System.out.print("Nivel (FPB / CFGM / CFGS): ");
            Alumno.Nivel nivel = Alumno.Nivel.valueOf(sc.nextLine().toUpperCase());

            Alumno nuevo = new Alumno(dni, nombre, nota, nivel);
            daw.insertar(nuevo);
            System.out.println("Alumno insertado correctamente.\n");
            
            System.out.println("\n Actualizar nota de un alumno");
            System.out.print("Introduce el DNI del alumno a actualizar: ");
            String dniActualizar = sc.nextLine();
            System.out.print("Introduce la nueva nota: ");
            float nuevaNota = Float.parseFloat(sc.nextLine());

            daw.actualizarNotaConCursor(dniActualizar, nuevaNota);

            // Mostrar nuestra lista actualizada
            System.out.println("Lista actualizada:");
            alumnos = daw.listar();
            for (Alumno a : alumnos) {
                System.out.println(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }
}


