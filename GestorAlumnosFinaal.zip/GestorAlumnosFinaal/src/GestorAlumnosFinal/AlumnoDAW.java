package GestorAlumnosFinal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlumnoDAW {

    private Connection conectar() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/insti";
        String user = "root";
        String password = "mysqlomayma"; 
        return DriverManager.getConnection(url, user, password);
    }

    public void insertar(Alumno a) throws SQLException {
        String sql = "INSERT INTO alumnosss (dni, nombre, nota, nivel) VALUES (?, ?, ?, ?)";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, a.getDni());
            ps.setString(2, a.getNombre());
            ps.setFloat(3, a.getNota());
            ps.setString(4, a.getNivel().name());
            ps.executeUpdate();
        }
    }

    public List<Alumno> listar() throws SQLException {
        List<Alumno> lista = new ArrayList<>();
        String sql = "SELECT * FROM alumnosss";
        try (Connection con = conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Alumno.Nivel nivel = Alumno.Nivel.valueOf(rs.getString("nivel"));
                Alumno a = new Alumno(
                    rs.getString("dni"),
                    rs.getString("nombre"),
                    rs.getFloat("nota"),
                    nivel
                );
                lista.add(a);
            }
        }
        return lista;
    }
    //eSTO LO AÑADO PARA PROBAR EL PUNTO 3(Probar, en las actualizaciones que necesiten un select 
    //previo, en vez de ejecutar otra query con UPDATE hacer la modificación sobre el cursor obtenido.)
    public void actualizarNotaConCursor(String dni, float nuevaNota) throws SQLException {
        String sql = "SELECT * FROM alumnos WHERE dni = ?";

        try (Connection con = conectar();
             PreparedStatement consulta = con.prepareStatement(
                     sql,
                     ResultSet.TYPE_FORWARD_ONLY,
                     ResultSet.CONCUR_UPDATABLE)) {

            consulta.setString(1, dni);
            ResultSet res = consulta.executeQuery();

            if (res.next()) {
                System.out.println("Actualizando nota de " + res.getString("nombre") +
                                   " de " + res.getFloat("nota") + " a " + nuevaNota);

                // Actualiza el valor en el ResultSet
                res.updateFloat("nota", nuevaNota);

                // Guarda el cambio en la base de datos
                res.updateRow();

                System.out.println("Nota actualizada");
            } else {
                System.out.println("No se encontró ningún alumno con ese DNI.");
            }
        }
    }

}
